class StaticElements
{
  static int DotsPerInch = 300;
  static double calcSquare(double wert)
  {
    return wert * wert;
  }
}
