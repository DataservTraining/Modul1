package com.herdt.java9.kap18;

class AnnotationDeprecated extends AnnotationDeprecatedSuper
{
  public static void main (String[] args)
  {
	  AnnotationDeprecated instance = new AnnotationDeprecated();
	  instance.writeText();
  }
}
