package com.herdt.java9.kap18;

class AnnotationOverrideSuper
{
  public void writeText()
  {
    System.out.println("Ausgabe der Superklasse");
  }

}
