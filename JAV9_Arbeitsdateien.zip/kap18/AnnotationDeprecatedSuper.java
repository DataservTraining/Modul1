package com.herdt.java9.kap18;

class AnnotationDeprecatedSuper
{
  @Deprecated
  public void writeText()
  {
    System.out.println("Ausgabe der Superklasse");
  }

}
