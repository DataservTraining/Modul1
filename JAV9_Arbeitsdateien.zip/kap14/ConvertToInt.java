package com.herdt.java9.kap14;

class ConvertToInt
{
  public static void main(String[] args)
  {
    String s = "ABC";
    int i = Integer.parseInt(s);
    System.out.println("Die Zahl ist " + i);
  }
}
