package com.herdt.java9.kap10;

interface Media
{
  void play();
  void stop();
  void display();
}