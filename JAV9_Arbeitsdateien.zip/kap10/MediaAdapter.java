package com.herdt.java9.kap10;

class MediaAdapter implements Media
{
  public void play() {}
  public void stop() {}
  public void display() {}
}