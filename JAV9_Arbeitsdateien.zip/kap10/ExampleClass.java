package com.herdt.java9.kap10;

public class ExampleClass
{
	public String saySomething()
	{
		return "Hallo aus der Klasse ExampleClass";
	}
}