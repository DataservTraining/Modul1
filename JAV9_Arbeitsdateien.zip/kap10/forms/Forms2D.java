package com.herdt.java9.kap10.forms;

/**
* Beschreibung eines Interfaces f�r zweidimensionale Formen
*/

public interface Forms2D
{
  double getArea();      //Flaecheninhalt ermitteln

  double getPerimeter(); //Umfang ermitteln
}
