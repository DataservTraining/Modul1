package com.herdt.java9.kap10.forms;

/**
* Beschreibung eines Interfaces f�r zweidimensionale Formen
*/

public interface Forms2D2 extends Forms2D
{
//geerbte  Methoden
//  double getArea();      //Flaecheninhalt ermitteln
//  double getPerimeter(); //Umfang ermitteln

  void turn90();           //um 90 Grad drehen
}
