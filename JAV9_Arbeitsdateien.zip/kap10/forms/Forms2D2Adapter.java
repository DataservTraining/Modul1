package com.herdt.java9.kap10.forms;

/**
* Beschreibung eines Interfaces f�r zweidimensionale Formen
*/

public class Forms2D2Adapter implements Forms2D2
{
//zu implementierende Methoden

  public double getArea() {return 0.0;}

  public double getPerimeter() {return 0.0;}

  public void turn90() {}
}
