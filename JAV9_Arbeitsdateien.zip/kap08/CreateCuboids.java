class CreateCuboids
{
  public static void main(String[] args)
  {
    Cuboid firstCuboid = new Cuboid();
  }
}
