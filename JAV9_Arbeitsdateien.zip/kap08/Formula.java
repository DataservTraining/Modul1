public final class Formula
{
  public static double getSquare(double value)
  {
    return (value * value);
  }
}
