package com.herdt.kap09pgckA;
import com.herdt.kap09pgckB.Welcome;

public class UseWelcome
{
	public static void main(String args[])
	{
		Welcome welcome = new Welcome();
		System.out.println( welcome.sayWelcome() );

	System.out.println ("Ende");

	}
}