package com.herdt.kap09pgckB;

public class Welcome
{
	public String sayWelcome()
	{
		return ("Willkommen!");
	}
}