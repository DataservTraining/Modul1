package com.herdt.kap09pgckC;

public class Intern
{
	public String saySomething()
	{
		System.out.println "Ich bin eine Klasse des internen Package kap09pgckC";
	}
}