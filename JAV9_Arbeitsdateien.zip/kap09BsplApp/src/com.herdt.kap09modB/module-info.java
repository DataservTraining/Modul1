module com.herdt.kap09modB {
	// Export des Package com.herdt.kap09pgckB
	exports com.herdt.kap09pgckB;
	// alle anderen Package des Modul kap09modB sind verborgen
}