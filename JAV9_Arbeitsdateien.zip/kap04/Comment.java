class Comment               //Definition der Klasse Comment (Kommentar)
{
  public static void main(String[] args)
  {
    System.out.println("Hallo Welt!");    //Mit dem Befehl System.out.println
                                          //koennen Sie einen Text ausgeben

/* zu Testzwecken als Kommentar:
  System.out.println("Hallo Europa!");    //diese Ausgabe ist als Kommentar
                                          //gekennzeichnet und wird daher
                                          //nicht ausgefuehrt
*/
   }
}
