class Hallowelt
{
  public static void main(String[] args)
  {
    System.out.println("Hallo Welt!");
  }
}