class Excercise3
{
  public static void main(String[] args)
  {
    int x = 5;

    x++;
    ++x;
    x = x + 1;
    //oder hierzu die verkuerzte Schreibweise
    x += 1;
  }
}
