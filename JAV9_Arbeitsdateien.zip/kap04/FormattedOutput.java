class FormattedOutput
{
  public static void main(String[] args)
  {
    int i = 213;
    double x = 3.5;
    System.out.printf("Eine Zahl: %d%nWert von i ist: %d%nWert von x ist: %g%n",7,i,x);
  }
}
