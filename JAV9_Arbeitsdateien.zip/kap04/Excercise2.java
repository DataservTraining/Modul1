class Excercise2
{
  public static void main(String[] args)
  {
    final int NUMBER1 = 12;
    final int NUMBER2 = 4;

    int sum        = NUMBER1 + NUMBER2;
    System.out.println(sum);

    int product    = NUMBER1 * NUMBER2;
    System.out.println(product);

    int difference = NUMBER1 - NUMBER2;
    System.out.println(difference);

    int quotient   = NUMBER1 / NUMBER2;
    System.out.println(quotient);
  }
}
