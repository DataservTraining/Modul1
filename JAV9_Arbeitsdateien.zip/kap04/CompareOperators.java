class CompareOperators
{
  public static void main(String[] args)
  {
    boolean isResultValid = true;
    boolean isValueOutOfRange = false;
    System.out.println(isResultValid);
    System.out.println(isValueOutOfRange);

    int i = 10;
    int j = 15;
    boolean b = i > j;    //b ist false
    System.out.println(i);
    System.out.println(j);
    System.out.println(b);
  }
}
