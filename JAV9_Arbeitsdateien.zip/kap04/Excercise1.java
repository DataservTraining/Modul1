class Excercise1
{
  public static void main(String[] args)
  {
    int a, b;     // das Komma fehlte

    a = b = 10;   // diese Anweisung ist korrekt.
                  // Es ist die verkuerzte Schreibweise f�r:
                  // a = 10;
                  // b = 10;

    System.out.println("Beide Zahlen haben jetzt den Wert 10");
    // die doppelten Anfuehrungszeichen fehlten
  }
}
