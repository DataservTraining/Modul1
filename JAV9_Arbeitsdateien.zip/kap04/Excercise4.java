class Excercise4
{
  public static void main(String[] args)
  {
    int d = 1;
    int e = 2;

    d *= e;
    d += e++;
    d -= 3 - 2 * e;
    e /= (d + 1);
  }
}
