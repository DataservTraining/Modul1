package com.herdt.java9.kap09;
import static java.lang.Math.PI;
class TestImport
{
  public static void main(String[] args)
  {
    int PI = 256; //hier nicht die Kreiszahl
    System.out.printf("PI: " + PI);
  }
}
