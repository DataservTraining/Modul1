package com.herdt.java9.kap19;
@FunctionalInterface
interface Converter
{
	double convert(double input);
}
