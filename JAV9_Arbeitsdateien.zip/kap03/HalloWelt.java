class HalloWelt
{
  public static void mai(String[] args)
  {
    System.out.println("Hallo Welt!");
  }
}