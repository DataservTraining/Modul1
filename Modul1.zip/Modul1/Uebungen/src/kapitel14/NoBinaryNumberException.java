package kapitel14;

public class NoBinaryNumberException extends RuntimeException {
	private static final long serialVersionUID = -1733075280120537221L;
	private String binaryNumber;
	private int position;

	public NoBinaryNumberException() {
		super();
	}

	public NoBinaryNumberException(String message) {
		super(message);
	}

	public NoBinaryNumberException(String binaryNumber, int position) {
		super();
		this.binaryNumber = binaryNumber;
		this.position = position;
	}

	public String getBinaryNumber() {
		return binaryNumber;
	}

	public int getPosition() {
		return position;
	}

	@Override
	public String getMessage() {
		
		return String.format("%s Fehler an Position %d\n", binaryNumber, position);
	}

	
	
}
