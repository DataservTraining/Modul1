package kapitel9;

import de.ba.test.Start;

public class Test {

	public static void main(String[] args) {
		Start s = new de.ba.test.Start();
		System.out.println(s.getClass().getPackageName().substring(3, 5));
	}

}
