package kapitel14loesung;

class NoBinaryNumberException extends RuntimeException
{
  public NoBinaryNumberException(String msg)
  {
    super(msg);
  }
  public NoBinaryNumberException()
  {
    super();
  }
  public NoBinaryNumberException(String s, int pos)
  {
    super(s + " ist keine Binaerzahl (" + pos + ". Stelle)");
  }
}
