package kapitel6;

public class SomeMaths {
  public static final double PI = 3.14159;
  
  public static double getSquare(double wert)  //Rueckgabewert: Quadrat
  {
    return wert * wert;
  }
}
