package kapitel6;

public class Circle
{
  double radius;

  public double getCircumference()   //Rueckgabewert: Kreisumfang
  {
    return 2 * SomeMaths.PI * radius;
  }

  public double getArea()            //Rueckgabewert: Kreisflaeche
  {
    return SomeMaths.PI * SomeMaths.getSquare(radius);
  }

}