package kapitel8;

public class ZeitFormat24 extends ZeitFormat {
	public ZeitFormat24() {
		this(0, 0);
	}

	public ZeitFormat24(int stunde, int minute) {
		super(stunde, minute);
	}

	public void ausgabe() {
		int m = getMinute();
		int s = getStunde();

		System.out.printf("Uhrzeit: %02d:%02d%n", s, m);
	}
}