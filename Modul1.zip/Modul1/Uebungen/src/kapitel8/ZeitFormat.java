package kapitel8;

public abstract class ZeitFormat extends Zeit {
	public ZeitFormat() {
		this(0, 0);
	}

	public ZeitFormat(int stunde, int minute) {
		super(stunde, minute);
	}

	protected abstract void ausgabe();
}