package kapitel8;

public class Zeit {
	
  private int stunde;
  private int minute;
  
  public Zeit()
  {
    this(0, 0);
  }

  public Zeit(int stunde, int minute)
  {
    setStunde(stunde);
    setMinute(minute);
  }

  public  void setStunde(int stunde)
  {
    if (stunde>=0 && stunde <= 23)
      this.stunde = stunde;
  }

  public void setMinute(int minute)
  {
    if (minute>=0 && minute<60)
      this.minute = minute;
  }

  public int getStunde()
  {
    return stunde;
  }

  public int getMinute()
  {
    return minute;
  }

  protected Object clone()
  {
    Zeit om = new Zeit(getStunde(), getMinute());
    return om;
  }

  public boolean equals(Object obj)
  {
    if (this == obj)
      return true;
    if ((obj == null) || (this.getClass() != obj.getClass()))
      return false;
    if (  (this.getStunde() == ((Zeit)obj).getStunde())
       && (this.getMinute() == ((Zeit)obj).getMinute()))
      return true;
    else
      return false;
  }
}