package kapitel8;

public class ZeitFormat12 extends ZeitFormat {
	public ZeitFormat12() {
		this(0, 0);
	}

	public ZeitFormat12(int stunde, int minute) {
		super(stunde, minute);
	}

	public void ausgabe() {
		int s = getStunde();
		boolean pm = s >= 12;
		int m = getMinute();
		if (pm)
			s -= 12;
		if (s == 0)
			s = 12;

		if (pm)
			System.out.printf("Uhrzeit: %02d:%02d PM%n", s, m);
		else
			System.out.printf("Uhrzeit: %02d:%02d AM%n", s, m);
		
//		System.out.printf("Uhrzeit: %02d:%02d %s%n", s, m, (pm ? "PM" : "AM"));
	}
}