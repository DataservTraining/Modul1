package kapitel7;

class SomeMaths
{
  static double pi = 3.14159;
  static double getSquare(double wert)  //Rueckgabewert: Quadrat
  {
    return wert * wert;
  }
}
