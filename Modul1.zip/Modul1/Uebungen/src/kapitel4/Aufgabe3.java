package kapitel4;

public class Aufgabe3 {

	public static void main(String[] args) {
		int x = 10;
		
		x = x + 1;
		++x;
		x++;
		x += 1;

	}

}
