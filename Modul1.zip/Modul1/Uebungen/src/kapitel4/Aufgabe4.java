package kapitel4;

public class Aufgabe4 {

	public static void main(String[] args) {
		int d = 1, e = 2;

		d *= e;  // d= 2, e = 2 
		System.out.printf("d: %d\te: %d\n", d, e);

		d += e++;  // d= 4, e = 3 
		System.out.printf("d: %d\te: %d\n", d, e);
		
		d -= 3 - 2 * e;  // d= 7, e = 3 
		System.out.printf("d: %d\te: %d\n", d, e);
		
		e /= (d + 1);    // d= 7, e = 0 
		System.out.printf("d: %d\te: %d\n", d, e);
		
		System.out.printf("");
	}

}
