package kapitel4;

public class Aufgabe2 {

	public static void main(String[] args) {
		final int NUMBER1 = 12, NUMBER2 = 4;
		
		int ergebnis;
		ergebnis = NUMBER1 + NUMBER2;
		System.out.printf("%d + %d = %d\n", NUMBER1, NUMBER2, ergebnis);

		ergebnis = NUMBER1 * NUMBER2;
		System.out.printf("%d * %d = %d\n", NUMBER1, NUMBER2, ergebnis);
		
		ergebnis = NUMBER1 - NUMBER2;
		System.out.printf("%d - %d = %d\n", NUMBER1, NUMBER2, ergebnis);
		
		ergebnis = NUMBER1 / NUMBER2;
		System.out.printf("%d / %d = %d\n", NUMBER1, NUMBER2, ergebnis);

	}

}
