package kapitel4;

public class Aufgabe1 {

	public static void main(String[] args) {
		int a, b;
		a = b = 10;
		System.out.println("Beide Zahlen haben jetzt den Wert 10");

	}

}
