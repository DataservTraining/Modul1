
public class TabellenDocument extends Document {

	@Override
	public void save() {
		System.out.println("Tabelle gespeichert");
	}

}
