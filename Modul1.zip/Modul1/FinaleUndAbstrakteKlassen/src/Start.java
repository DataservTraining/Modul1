
public class Start {
	
	public static void main(String[] args) {
		Application word = new TextApplication();
		word.newDocument();
		
		Application excel = new TabellenApplication();
		excel.newDocument();
	}

}
