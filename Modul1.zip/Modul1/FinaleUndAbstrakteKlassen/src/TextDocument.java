
public class TextDocument extends Document {

	@Override
	public void save() {
		System.out.println("Textdokument gespeichert");
	}

}
