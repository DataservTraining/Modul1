
public abstract class Application {
	private Document[] docs = new Document[10];
	private int index;
	
	public void newDocument() {
		// pr�fen ob Platz im Array
		if(index < docs.length) {
		// Dokument erzeugen
			Document doc = createDocument();
		// Dokument in Array ablegen
			docs[index] = doc;
		// index hochz�hlen
			++index;
		// Dokument abspeichern
			doc.save();
			
		} else {
			System.out.println("kein Platz mehr");
		}
	}

	protected abstract Document createDocument();

}
