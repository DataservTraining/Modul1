
public class TabellenApplication extends Application {

	@Override
	protected Document createDocument() {
		return new TabellenDocument();
	}

}
