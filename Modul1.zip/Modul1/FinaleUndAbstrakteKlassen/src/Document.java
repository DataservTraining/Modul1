
public abstract class Document {

	public abstract void save();

}
