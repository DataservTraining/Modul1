package package2;

//import package1.A1;

public class C2 extends package1.A1{
	public void test() {
		package1.A1 a1 = new package1.A1();
//		System.out.println("x: " + a1.x);
//		System.out.println("y: " + a1.y);
//		System.out.println("y: " + y);
//		System.out.println("z: " + a1.z);
		System.out.println("z: " + z);
		System.out.println("w: " + a1.w);
	}
}
