import package1.B1;

public class A {
	B1 b1 = new B1();
}
