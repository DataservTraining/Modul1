package application;

import package1.A1;
import package1.B1;
import package2.C2;
import static java.lang.Math.*;
import static package1.A1.*;

public class Start {

	public static void main(String[] args) {
		A1 a1 = new A1();
		B1 b1 = new B1();
		C2 c2 = new C2();
		double quadrat = pow(4, 2);
		double squareRoot = sqrt(4);
		System.out.println(quadrat);
		System.out.println(Math.PI);
		Inner inner = new Inner();
	}

}
