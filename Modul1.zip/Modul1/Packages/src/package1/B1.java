package package1;

public class B1 {
	
	public void test() {
		A1 a1 = new A1();
//		System.out.println("x: " + a1.x);
		System.out.println("y: " + a1.y);
		System.out.println("z: " + a1.z);
		System.out.println("w: " + a1.w);
	}
}
