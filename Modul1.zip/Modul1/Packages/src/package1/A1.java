package package1;

public class A1 {
	private int x = 10;
	int y = 20;
	protected int z = 30;
	public int w = 40;
	
	public void test() {
		System.out.println("x: " + x);
		System.out.println("y: " + y);
		System.out.println("z: " + z);
		System.out.println("w: " + w);
	}
	
	public static class Inner{
		
	}
}
