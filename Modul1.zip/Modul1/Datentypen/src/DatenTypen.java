

public class DatenTypen {

	public static void main(String[] args) {
		// Ganzzahlen
		byte erstesByte = -7, zweitesByte = +8;
		short ersterShort = 12312;
		int ersterInt = 345345;
		ersterInt = 0xAB15;
		ersterInt = 017;
		ersterInt = 0B10_11;
		System.out.println(ersterInt);
		long ersterLong = 2_344_244_345L;

		//Flie�kommazahlen
		float ersterFloat = 34.5F;
		double ersterDouble = 765.8;
		
		boolean ok = true; // oder false
		
		char erstesChar = 'A';
		erstesChar = 65;
		erstesChar = '\u0041';
		erstesChar = '\t'; // Tabulator
		erstesChar = '\n'; // Zeilenumbruch
		erstesChar = '\"'; // Zeilenumbruch
		erstesChar = '\''; // Zeilenumbruch
		erstesChar = '\\'; // Zeilenumbruch
		String text = "Hallo \"sch�ne\" Welt";
		String pfad = "c:\\windows\\system";
		System.out.println(text);
		{
			int x = 5;
			System.out.println(x);
		}
		
//		System.out.println(x);
		
		int y, z;
		y = z = 6;
		
		byte ergebnis = (byte) (erstesByte + zweitesByte);
		ersterInt = ersterShort;
		System.out.println(y);
		System.out.println(z);
		
		final double PI = 3.14156;
		final int ERSTE_INT_KONSTANTE = 123;
		
		
		
	}

}
