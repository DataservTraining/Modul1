import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Dateibearbeitung {

	public String leseDatei(String name) throws FileNotFoundException, IOException {
		StringBuilder builder = new StringBuilder();
		BufferedReader in = null;
		try {
			in = new BufferedReader(new FileReader(name));
			String zeile = null;
			while ((zeile = in.readLine()) != null) {
				builder.append(zeile);
			}
		} catch (FileNotFoundException e) {
			System.out.println("Logging FileNotFound");
//			throw new NullPointerException("message");
			throw e;
		} catch (IOException e) {
			System.out.println("Logging IOException");
			throw e;
		} finally {
			try {
				in.close();
			} catch (NullPointerException e) {
				System.out.println("Logging NullPointer");
			}
		}
		return builder.toString();

	}

}
