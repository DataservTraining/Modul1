import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Start {

	public static void main(String[] args) {
		// Syntaxfehler
//		int x = "Hallo";
		int y = 9, z = 0, erg = 0;
		
		int note = 6;
		
		// logische Fehler
		// Debugger
		if(note > 0 || note < 5 ) {
			System.out.println("bestanden");
		}
		
		int[] feld = new int[3];
//		feld[3] = 10;
		
		Person p = null;
		if (p != null) {
			System.out.println(p.getAge());
		}
		
		boolean test = true;
//		PrintWriter out = null;
		Dateibearbeitung db = new Dateibearbeitung();
		try {
			if(test) throw new MyFileException("MyFileException", "main(String[] args)", 34, 123213);
			String text = db.leseDatei("test.txt");
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (MyFileException e) {
			System.out.println(e);
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
		
		
		
		try (PrintWriter out = new PrintWriter(new FileWriter("c:\text.txt")); 
			 Scanner scanner = new Scanner(System.in)) {
			erg = y / z;
			System.out.println(erg);
			
			
		} 
		catch (ArithmeticException e) {
			System.out.println(e.getMessage());
			
		} catch (ArrayIndexOutOfBoundsException e) {
			
		} catch (RuntimeException e) {
			
		} catch (Exception e) {
			
		}
		finally {
//			if (out != null) out.close();
			System.out.println("finally");
		}
		
		
		System.out.println("Ende");

	}

}
