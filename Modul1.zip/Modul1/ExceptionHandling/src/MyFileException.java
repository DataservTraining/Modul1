import java.io.IOException;

public class MyFileException extends Exception{
	private static final long serialVersionUID = 1L;
	
	private String methode;
	private int zeile;
	private int fehlerNummer;
	
	public MyFileException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MyFileException(String methode, int zeile, int fehlerNummer) {
		super();
		this.methode = methode;
		this.zeile = zeile;
		this.fehlerNummer = fehlerNummer;
	}

	public MyFileException(String message, String methode, int zeile, int fehlerNummer) {
		super(message);
		this.methode = methode;
		this.zeile = zeile;
		this.fehlerNummer = fehlerNummer;
	}

	public MyFileException(String message) {
		this(message, "keine Angabe", 0, 0);
	}

	public String getMethode() {
		return methode;
	}

	public int getZeile() {
		return zeile;
	}

	public int getFehlerNummer() {
		return fehlerNummer;
	}

	@Override
	public String getMessage() {
		
		return super.getMessage() + String.format("\nin Methode %s in Zeile %d mit Fehlercode %d\n", methode, zeile, fehlerNummer);
	}
	
	
	
	

}
