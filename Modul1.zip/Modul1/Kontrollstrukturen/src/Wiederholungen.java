
public class Wiederholungen {

	public static void main(String[] args) {
		int zaehler2 = 0;
		for (int zaehler = 0; zaehler < 10; ++zaehler) {
			System.out.println(zaehler);
		}
		
		for(;;) {
			System.out.println(zaehler2++);
			if(zaehler2==10) {
				break;
			}
		}

		int x = 1;
		
		while(x < 10) {
			System.out.println("while: " + x++);
		}
		
		do {
			System.out.println("do-while: " + x--);
		} while(x > 0);
		
	}

}
