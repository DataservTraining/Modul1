
public class Verzweigungen {

	public static void main(String[] args) {
		int x = 5, y = 5, z = 8;
		
		if(x == 4) {
			System.out.println("x == 4");
		}
		
		if(x == 4) System.out.println("x == 4");
		
		if(x == 4) { 
			System.out.println("x == 4");
			System.out.println("Test");
		} else {
			System.out.println("x != 4");
		}
		
		if(x == 4) {
			System.out.println("x == 4");
			System.out.println("Test");
		} else if (y == 8) {
			System.out.println("y == 8");
		} else {
			System.out.println("x != 4");
			System.out.println("y != 8");
		}
		
		int note = 5;
		
		switch (note) {
		case 1:
			System.out.println("sehr gut");
			break;
		case 2:
			System.out.println("gut");
			break;
		case 3:
			System.out.println("befriedigend");
			break;
		case 4:
			System.out.println("ausreichend");
			break;
		case 5:
			System.out.println("mangelhaft");
			break;
		case 6:
			System.out.println("ungen�gend");
			break;
		default:
			System.out.println("ung�ltige Note");
		}
		
		switch (note) {
		case 1:
		case 2:
		case 3:
		case 4:
			System.out.println("bestanden");
			break;
		case 5:
		case 6:
			System.out.println("nicht bestanden");
			break;
		default:
			System.out.println("ung�ltige Note");
		}

		
		// ===================================================
		
		switch (note) {
		case 1:
			System.out.print("sehr ");
		case 2:
			System.out.println("gut");
			break;
		case 3:
			System.out.println("befriedigend");
			break;
		case 4:
			System.out.println("ausreichend");
			break;
		case 5:
			System.out.println("mangelhaft");
			break;
		case 6:
			System.out.println("ungen�gend");
			break;
		default:
			System.out.println("ung�ltige Note");
		}
		
		switch (note) {
		case 5:
		case 6:
			System.out.print("nicht ");
		case 1:
		case 2:
		case 3:
		case 4:
			System.out.println("bestanden");
			break;
		default:
			System.out.println("ung�ltige Note");
		}

		
	}

}
