package application;

public class Start {

	public static void main(String[] args) {
//	MySQLDB db = new MySQLDB();
		DBInterface db = DBFactory.createDB();
		
		Rechteck r = new Rechteck();
		db.saveRechteck(r);
		Rechteck geladen = db.loadRechteck();
		db.removeRechteck(r);

	}

}
