
package application;

public class OracleDB implements DBInterface {
	public void saveRechteck(Rechteck r) {
		System.out.println("Rechteck in Oracle gespeichert");
	}
	
	public Rechteck loadRechteck() {
		System.out.println("Rechteck aus Oracle geladen");
		return new Rechteck();
	}

	@Override
	public void removeRechteck(Rechteck r) {
		System.out.println("Rechteck aus Oracle gel�scht");
		
	}
}
