package application;

public class DBFactory {
	
	public static DBInterface createDB() {
		return new OracleDB();
	}

}
