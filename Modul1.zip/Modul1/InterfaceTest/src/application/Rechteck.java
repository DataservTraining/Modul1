package application;
import java.util.Objects;

public class Rechteck extends Object {
	private double laenge;
	private double breite;
	private int farbe;
	private static int anzahl;
	private boolean geloescht = false;
	
	public Rechteck() {
//		System.out.println("Stanardkonstruktor");
		this(1, 1, 0);
//		setLaenge(1);
//		setBreite(1);
	}
	
	public Rechteck(double seitenlaenge) {
		this(seitenlaenge, seitenlaenge, 0);
//		setLaenge(seitenlaenge);
//		setBreite(seitenlaenge);
	}
	
	public Rechteck(double laenge, double breite) {
		this(laenge, breite, 0);
//		setLaenge(laenge);
//		setBreite(breite);
	}

	public Rechteck(double laenge, double breite, int farbe) {
		setLaenge(laenge);
		setBreite(breite);
		setFarbe(farbe);
		++anzahl;
	}
	
	
	
	@Override
	public void finalize() throws Throwable {
		// TODO Auto-generated method stub
		if(!geloescht) --anzahl;
		geloescht = true;
	}

	public static int getAnzahl() {
		return anzahl;
	}

	public double getLaenge() {
		return laenge;
	}
	
	public double getBreite() {
		return breite;
	}
	
	public void setLaenge(double l) {
		if(l < 0) {
			System.out.println("ung�ltiger Wert f�r die L�nge: " + l);
			return;
		}
		laenge = l;
	}
	
	public void setBreite(double breite) {
		if(breite < 0) {
			System.out.println("ung�ltiger Wert f�r die Breite: " + breite);
			return;
		}
		this.breite = breite;
	}
	
	
	
	public int getFarbe() {
		return farbe;
	}

	public void setFarbe(int farbe) {
		if(farbe < 0) {
			System.out.println("ung�ltiger Wert f�r die Farbe: " + farbe);
			return;
		}
		this.farbe = farbe;
	}

	public void swapWidthLength() {
		double temp = laenge;
		laenge = breite;
		breite = temp;
	}
	
	public void buildSquare(double seitenlaenge) {
		setLaenge(seitenlaenge);
		setBreite(seitenlaenge);
	}
	
	public double getArea() {
		return laenge * breite;
	}
	
	public void resize (double faktor) {
		setLaenge(faktor * laenge);
		setBreite(faktor * breite);
	}
	
	public void resize (double faktorLaenge, double faktorBreite) {
		setLaenge(faktorLaenge * laenge);
		setBreite(faktorBreite * breite);
	}
	
	public void show() {
		System.out.printf("Rechteckdaten:\n");
		System.out.printf("L�nge:    %.2f\n", laenge);
		System.out.printf("Breite:   %.2f\n", breite);
		System.out.printf("Fl�che:   %.2f\n", getArea());
		System.out.printf("Farbe:    %X\n", getFarbe());
		
	}

	@Override
	public String toString() {
		return "Rechteck [laenge=" + laenge + ", breite=" + breite + ", farbe=" + farbe + ", getArea()=" + getArea()
				+ "]";
	}

	@Override
	public Object clone() throws CloneNotSupportedException {
		Rechteck temp = new Rechteck(laenge, breite, farbe);
		return temp;
	}

	@Override
	public int hashCode() {
		return Objects.hash(breite, farbe, laenge);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Rechteck other = (Rechteck) obj;
		return Double.doubleToLongBits(breite) == Double.doubleToLongBits(other.breite) && farbe == other.farbe
				&& Double.doubleToLongBits(laenge) == Double.doubleToLongBits(other.laenge);
	}
	
	
	
	
	
}
