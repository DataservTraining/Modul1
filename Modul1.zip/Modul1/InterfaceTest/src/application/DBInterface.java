package application;

public interface DBInterface {
	public static final int ATTRIBUTE = 34; 
	public abstract void saveRechteck(Rechteck r);
	public Rechteck loadRechteck();
	public void removeRechteck(Rechteck r);

	// ab Java 8
	public default void test() {
		
	}
	
	// ab Java 9 ???
	public static void xyz() {
		
	}
}
