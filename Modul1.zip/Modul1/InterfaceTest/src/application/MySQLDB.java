package application;

public class MySQLDB implements DBInterface{
	
	public void saveRechteck(Rechteck r) {
		System.out.println("Rechteck in MySQL gespeichert");
	}
	
	public Rechteck loadRechteck() {
		System.out.println("Rechteck aus MySQL geladen");
		return new Rechteck();
	}

	@Override
	public void removeRechteck(Rechteck r) {
		System.out.println("Rechteck aus MySQL gel�scht");
		
	}
	
	

}
