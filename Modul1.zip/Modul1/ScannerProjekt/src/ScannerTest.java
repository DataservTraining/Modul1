import java.util.Scanner;

public class ScannerTest {

	public static void main(String[] args) {
		System.out.println("Bitte Zahl eingeben:");
		Scanner scanner = new Scanner(System.in);
		int x;
		x = scanner.nextInt();
		System.out.println(x);
		double d1;
		System.out.println("double?");
		d1 = scanner.nextDouble();
		System.out.println(d1);
		String text;
		System.out.println("Text?");
		scanner.nextLine();
		text = scanner.next();
		System.out.println(text);
		scanner.close();
	}

}
