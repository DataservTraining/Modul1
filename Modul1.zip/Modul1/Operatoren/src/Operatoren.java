
public class Operatoren {

	public static void main(String[] args) {
		// Arithmetische Operatoren
		// +, -, *, /, %
		int wert1 = 30, wert2 = 7;
		double ergebnis;
		ergebnis =  wert1 % (wert2 + 2);
		System.out.println(ergebnis);
		
		double f1 = 7.9, f2 = 3.5;
		
		System.out.println(f1 % f2);
		
		// Zuweisungsoperatoren
		
		wert1 += 12; // wert1 = wert1 + 12
		wert1 *= 12 + 3; // wert1 = wert1 * (12 + 3) 
		
		// Inkrement- und Dekrementoperator
		// ++, --
		wert1 = 30;
		++wert1;
		--wert1;
		wert1++;
		wert1--;
		
		ergebnis = ++wert1 * wert2;
		
		System.out.println("wert1: " + wert1 + "\tergebnis: " + ergebnis);
		
		// Vergleichsoperatoren
		// <, >, <=, >=, ==, !=
		
		boolean ok = wert1 != wert2;
		
		System.out.println(ok);
		
		// logische Operatoren
		// && oder & (and), || oder | (or), ^ (xor), ! (not)
		System.out.println("===========================================");
		wert2 = 17;
		System.out.println("wert1: " + wert1 + "\twert2: " + wert2);
		ok = wert1 > 30 && wert2 < 10;
		System.out.println(ok);
		ok = wert1 > 30 || wert2 < 10;
		System.out.println(ok);
		ok = wert1 > 30 ^ wert2 < 10;
		System.out.println(ok);
		
		ok = !ok;
		System.out.println(ok);
		
		System.out.printf("Die Addition von Wert1 und Wert2 ergibt %20.2f\n", ergebnis);
		System.out.printf("%03d + %03d = %f\n", wert1, wert2, 23432423.234234234);
		System.out.printf("%02d:%02d\n", 19, 15);
		
	}

}
