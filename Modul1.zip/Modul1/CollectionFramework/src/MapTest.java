import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class MapTest {

	public static void main(String[] args) {
		Map<String, Person> personenMap = new TreeMap<>();
		
		List<Person> personenListe = DemoData.createDemoData();
		
		for(Person p : personenListe) {
			personenMap.put(p.getEmail1(), p);
			personenMap.put(p.getEmail2(), p);
		}
		
		for(String key : personenMap.keySet()) {
			System.out.println("Key: " + key + "\t\tDaten: " + personenMap.get(key));
		}
		System.out.println();
		for(Map.Entry<String, Person> entry : personenMap.entrySet()) {
			System.out.println("Key: " + entry.getKey() + "\t\tDaten: " + entry.getValue());
		}
		
		Person altePerson = personenMap.put("Tom3@t-online.de", new Person("unbekannt", 0));
		System.out.println("=====>: " + altePerson);
		
		System.out.println();
		for(Map.Entry<String, Person> entry : personenMap.entrySet()) {
			System.out.println("Key: " + entry.getKey() + "\t\tDaten: " + entry.getValue());
		}
	}

}
