import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class ListTest {

	public static void main(String[] args) {
		List<String> strings = new LinkedList<>();
		List<Integer> integers = new ArrayList<>();
		
		for(int x = 1; x < 11; ++x) {
			integers.add(null);
		}
		
//		for(int i : integers) {
//			System.out.print(i + ", ");
//		}
		
		for(int index = 0; index < integers.size(); ++index) {
			System.out.print(integers.get(index) + ", ");
		}
		
		System.out.println();
		
		for(int i = 1; i < 11; ++i) {
			strings.add("Eintrag " + (i));
		}
		
		for(String s : strings) {
			System.out.print(s + ", ");
		}
		System.out.println();
		
		strings.remove("Eintrag 5");

		for(String s : strings) {
			System.out.print(s + ", ");
		}
		
		System.out.println();
		strings.remove(0);
		for(String s : strings) {
			System.out.print(s + ", ");
		}
		System.out.println();
		String eintrag = strings.get(4);
		System.out.println(eintrag);

		
		System.out.println(strings.contains("Eintrag 18"));
	}

}
