import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class SetTest {

	public static void main(String[] args) {
		Set<String> strings = new HashSet<>();
		
		for(int index = 1; index < 11; ++index) {
			strings.add("Eintrag " + index);
		}
		
		for(String s : strings) {
			System.out.print(s + ", ");
		}
		
		System.out.println();
		
//		System.out.println(strings.contains("Eintrag 6"));
		
		Iterator<String> it = strings.iterator();
		
		while(it.hasNext()) {
			String temp = it.next();
			System.out.print(temp + ", ");
		}
		System.out.println();
		String[] stringsArray = strings.toArray(new String[0]);
		
		for(int index = 0; index < stringsArray.length; ++ index) {
			System.out.print(stringsArray[index] + ", ");
		}
System.out.println();

//public static List<String> createDemoNames() {
//	final List<String> names = new ArrayList<>();
//	names.add("   Max");
//	names.add(""); // Leereintrag
//	names.add("  Andy  ");
//	names.add(" "); // potenziell auch ein "Leereintrag"
//	names.add("Stefan");
//	names.add(null);
//	return names;
		Set<String> namen = new TreeSet<>(DemoData.createDemoNames());
		
		System.out.println(namen);
		
		Set<Integer> integers = new TreeSet<>();
		for(int index = 0; index < 11; ++index) {
			int wert = (int)(Math.random() * 100 + 1);
			System.out.print(wert + ", ");
			integers.add(wert);
		}
		System.out.println();
		System.out.println(integers);
		System.out.println();
		
//		public static List<Person> createDemoData() {
//			final List<Person> persons = new ArrayList<>();
//			persons.add(new Person("Michael", 44));
//			persons.add(new Person("Barbara", 22, Gender.FEMALE));
//			persons.add(new Person("Lili", 17, Gender.FEMALE));
//			persons.add(new Person("Tom", 8));
//			persons.add(new Person("Bj�rn", 7));
//			return persons;
//		}
		Set<Person> personen = new TreeSet<>(DemoData.createDemoData());
		System.out.println(personen);
		System.out.println("\n===========================================\n");
		Set<Person> personen2 = new TreeSet<>(new AgeComparator());
		personen2.addAll(DemoData.createDemoData());
		System.out.println(personen2);
		
		
		
	}

}
