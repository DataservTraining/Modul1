package application;

import static application.Stockwerk.*;

public class EnumTest {

	public static void main(String[] args) {
		Stockwerk stockwerk = OG1;
		System.out.println("MaxInt: " + Integer.MAX_VALUE + "\tMinInt: " + Integer.MIN_VALUE);
		System.out.println("MaxInt: " + Integer.MAX_VALUE + "\tMinInt: " + Integer.MIN_VALUE);
		
		for(Stockwerk s : Stockwerk.values()) {
			System.out.print(s + ", ");
			System.out.print(s.name() + ", ");
			System.out.println(s.ordinal());
		}
		
	}

}
