package application;

public class ArrayTest {

	public static void main(String[] args) {
		int[] feld = new int[10];
		int x1 = 10;
		int x2 = 7;
		
		int index = 1;
		
//		System.out.println(x+index);
		
		feld[0] = 45;
		System.out.println(feld[0]);
		
		for(int i = 0; i < feld.length; ++i) {
			feld[i] = (int) (Math.random() * 100 + 1);
		}
		
		
		for(int i = 0; i < feld.length; ++i) {
			System.out.print(feld[i] + ", ");
		}
		
		System.out.println();
		for(int element : feld) {
			System.out.print(element + ", ");
			element = 0;
		}
		System.out.println();
		
		for(int element : feld) {
			System.out.print(element + ", ");
		}
		System.out.println("\n==========================================\n");
		
		Punkt[] punkte = new Punkt[10];
		
		for(int i = 0; i < feld.length; ++i) {
			punkte[i] = new Punkt((int) (Math.random() * 100 + 1), (int) (Math.random() * 100 + 1));
		}
		
		for(Punkt punkt : punkte) {
			System.out.print(punkt + ", ");
			punkt.setPosX(0);
			punkt.setPosY(0);
		}
		
		System.out.println();
		for(Punkt punkt : punkte) {
			System.out.print(punkt + ", ");
		}
		

	}

}
