package application;

public enum Stockwerk {
	UG2, UG1, EG, OG1, OG2
}
