package application;

import java.beans.XMLDecoder;
import java.beans.XMLEncoder;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.List;

public class XMLSerialisierung {

	public static void main(String[] args) {
		List<Person> personen = DemoData.createDemoData();
		
		try {
			XMLEncoder encoder = new XMLEncoder(new FileOutputStream("personen.xml"));
//			Test t = new Test("dkjfhkj", 435);
			
//			encoder.writeObject(t);
			for(Person person : personen) {
				encoder.writeObject(person);
			}
			encoder.close();
			
//			XMLDecoder decoder = new XMLDecoder(new FileInputStream("personen.xml"));
//			Test t1 = (Test) decoder.readObject();
//			decoder.close();
//			System.out.println(t1);
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

}
