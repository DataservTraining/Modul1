package application;

public class Lebewesen {
	public Lebewesen(String x) {}
	public Lebewesen() {}
}
