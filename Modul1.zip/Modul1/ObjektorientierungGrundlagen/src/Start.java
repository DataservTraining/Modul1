
public class Start {

	public static void main(String[] args) {
		Rechteck r1;
		r1 = new Rechteck();
		Rechteck r2 = new Rechteck();

		
		
		r1.setBreite(-34);
		r1.setLaenge(100);
		
		r2.setLaenge(78);
		r2.setBreite(98);

		r1.show();
		r2.show();
	}
	


}
