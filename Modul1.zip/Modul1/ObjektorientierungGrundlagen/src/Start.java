
public class Start {

	public static void main(String[] args) throws Throwable {
		System.out.println(Rechteck.getAnzahl());
		Rechteck r1;
		r1 = new Rechteck();
		System.out.println(Rechteck.getAnzahl());
		Rechteck r2 = new Rechteck();
		System.out.println(Rechteck.getAnzahl());
		Rechteck r3 = new Rechteck(3);
		System.out.println(Rechteck.getAnzahl());
		Rechteck r4 = new Rechteck(78.6, 34.2, 0xABFFD3);
		System.out.println(Rechteck.getAnzahl());

		Quader quader1 = new Quader(34.6, 12.67, 435.78, 0);
		System.out.println(Rechteck.getAnzahl());
		
		quader1.show();
		
		Rechteck quader2 = new Quader(789.6, 167.67, 435.78, 0);
		System.out.println(Rechteck.getAnzahl());
		quader2.show();
		System.out.println(((Quader)quader2).getVolumen());
		quader2.finalize();
		quader2 = r4;
		System.gc();
		Thread.sleep(50);
		System.out.println("Anzahl nach \"quader2 = r4;\": " + Rechteck.getAnzahl());
		if(quader2 instanceof Quader) {
			System.out.println(((Quader)quader2).getVolumen());
		} else {
			System.out.println("r4 ist kein Quader");
		}
		
		System.out.println(quader2);
		
		Rechteck clone = (Rechteck)r4.clone();
		System.out.println(clone);
		clone.setBreite(0);
		System.out.println(quader2);
		System.out.println(clone);
	}
	


}
