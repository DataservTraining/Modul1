
public class Start {

	public static void main(String[] args) {
		Rechteck r1;
		r1 = new Rechteck();
		Rechteck r2 = new Rechteck();
		r1.show();
		r2.show();
		Rechteck r3 = new Rechteck(3);
		r3.show();
		Rechteck r4 = new Rechteck(78.6, 34.2, 0xABFFD3);
		r4.show();
		
		
		r1.setBreite(34);
		r1.setLaenge(100);
		
		r2.setLaenge(78);
		r2.setBreite(98);

		r1.show();
		r2.show();
	}
	


}
