
public class KlasseMitKlassenattributen {
	private static int test = 0;
	public static final double PI = 3.14156;
	
	public static int getTest() {
		return test;
	}
	
	public static void setTest(int test) {
		KlasseMitKlassenattributen.test = test;
	}

}
