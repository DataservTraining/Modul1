
public class MethodenUeberladen {

	public static void main(String[] args) {
		greetings();
		greetings("Hans");
		greetings();
		greetings("Fritz");	
		greetings();
		greetings("Else");
		
		int ergebnis = add(2, 5);
		double erg = add(6.7, 9.5);
		System.out.println(ergebnis);
		System.out.println(erg);
	}
	
	public static void greetings() {
		System.out.println("Hallo Welt");
		return;
	}
	
	public static void greetings(String name) {
		System.out.println("Hallo " + name);
	}
	
	public static int add(int a, int b) {
		return a + b;
	}

	public static double add(double a, double b) {
		return a + b;
	}

}
