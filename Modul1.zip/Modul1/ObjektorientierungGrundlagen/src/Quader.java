
public class Quader extends Rechteck {
	private double hoehe;
	
	public Quader() {
		this(1, 1, 1, 0);
	}
	
	public Quader(double laenge, double breite, double hoehe, int farbe) {
		super(laenge, breite, farbe);
//		setLaenge(laenge);
//		setBreite(breite);
//		setFarbe(farbe);
		setHoehe(hoehe);
	}

	public double getHoehe() {
		return hoehe;
	}

	public void setHoehe(double hoehe) {
		if(hoehe < 0) {
			System.out.println("ung�ltiger Wert f�r die H�he: " + hoehe);
			return;
		}
		this.hoehe = hoehe;
	}
	
	
	
	@Override
	public double getArea() {
		return 2* (super.getArea() + ((getLaenge() + getBreite()) * hoehe));
	}
	
	public double getVolumen() {
		return super.getArea() * hoehe;
	}

	@Override
	public void show() {
		System.out.println("Quaderdaten:");
		super.show();
		System.out.printf("zus�tzlich Daten der Klasse Quader\n");
		System.out.printf("H�he:     %.2f\n", hoehe);
	}
}
