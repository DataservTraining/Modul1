
public class TestKlassenAttribute {

	public static void main(String[] args) {
		KlasseMitKlassenattributen.setTest(23);
		KlasseMitKlassenattributen k1 = new KlasseMitKlassenattributen();
		KlasseMitKlassenattributen k2 = new KlasseMitKlassenattributen();
		KlasseMitKlassenattributen k3 = new KlasseMitKlassenattributen();
		System.out.println(k1.getTest());
		System.out.println(k2.getTest());
		System.out.println(k3.getTest());
		KlasseMitKlassenattributen.setTest(34);
		System.out.println(k1.getTest());
		System.out.println(k2.getTest());
		System.out.println(k3.getTest());
		System.out.println(KlasseMitKlassenattributen.getTest());
		System.out.println(KlasseMitKlassenattributen.PI);

	}

}
