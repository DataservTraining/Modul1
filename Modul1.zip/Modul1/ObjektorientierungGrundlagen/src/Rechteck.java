
public class Rechteck {
	private double laenge;
	private double breite;
	
	
	public double getLaenge() {
		return laenge;
	}
	
	public double getBreite() {
		return breite;
	}
	
	public void setLaenge(double l) {
		if(l < 0) {
			System.out.println("ung�ltiger Wert f�r die L�nge: " + l);
			return;
		}
		laenge = l;
	}
	
	public void setBreite(double breite) {
		if(breite < 0) {
			System.out.println("ung�ltiger Wert f�r die Breite: " + breite);
			return;
		}
		this.breite = breite;
	}
	
	public void swapWidthLength() {
		double temp = laenge;
		laenge = breite;
		breite = temp;
	}
	
	public void buildSquare(double seitenlaenge) {
		setLaenge(seitenlaenge);
		setBreite(seitenlaenge);
	}
	
	public double getArea() {
		return laenge * breite;
	}
	
	public void resize (double faktor) {
		setLaenge(faktor * laenge);
		setBreite(faktor * breite);
	}
	
	public void resize (double faktorLaenge, double faktorBreite) {
		setLaenge(faktorLaenge * laenge);
		setBreite(faktorBreite * breite);
	}
	
	public void show() {
		System.out.printf("Rechteckdaten:\n");
		System.out.printf("L�nge:    %.2f\n", laenge);
		System.out.printf("Breite:   %.2f\n", breite);
		System.out.printf("Fl�che:   %.2f\n", getArea());
		
	}
	
}
