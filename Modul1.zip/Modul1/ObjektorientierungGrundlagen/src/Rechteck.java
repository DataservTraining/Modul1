
public class Rechteck {
	private double laenge;
	private double breite;
	int farbe;
	
	public Rechteck() {
		System.out.println("Stanardkonstruktor");
		setLaenge(1);
		setBreite(1);
	}
	
	public Rechteck(double seitenlaenge) {
		setLaenge(seitenlaenge);
		setBreite(seitenlaenge);
	}
	
	public Rechteck(double laenge, double breite) {
		setLaenge(laenge);
		setBreite(breite);
	}

	public Rechteck(double laenge, double breite, int farbe) {
		setLaenge(laenge);
		setBreite(breite);
		setFarbe(farbe);
	}
	
	public double getLaenge() {
		return laenge;
	}
	
	public double getBreite() {
		return breite;
	}
	
	public void setLaenge(double l) {
		if(l < 0) {
			System.out.println("ung�ltiger Wert f�r die L�nge: " + l);
			return;
		}
		laenge = l;
	}
	
	public void setBreite(double breite) {
		if(breite < 0) {
			System.out.println("ung�ltiger Wert f�r die Breite: " + breite);
			return;
		}
		this.breite = breite;
	}
	
	
	
	public int getFarbe() {
		return farbe;
	}

	public void setFarbe(int farbe) {
		if(farbe < 0) {
			System.out.println("ung�ltiger Wert f�r die Farbe: " + farbe);
			return;
		}
		this.farbe = farbe;
	}

	public void swapWidthLength() {
		double temp = laenge;
		laenge = breite;
		breite = temp;
	}
	
	public void buildSquare(double seitenlaenge) {
		setLaenge(seitenlaenge);
		setBreite(seitenlaenge);
	}
	
	public double getArea() {
		return laenge * breite;
	}
	
	public void resize (double faktor) {
		setLaenge(faktor * laenge);
		setBreite(faktor * breite);
	}
	
	public void resize (double faktorLaenge, double faktorBreite) {
		setLaenge(faktorLaenge * laenge);
		setBreite(faktorBreite * breite);
	}
	
	public void show() {
		System.out.printf("Rechteckdaten:\n");
		System.out.printf("L�nge:    %.2f\n", laenge);
		System.out.printf("Breite:   %.2f\n", breite);
		System.out.printf("Fl�che:   %.2f\n", getArea());
		System.out.printf("Farbe:    %X\n", getFarbe());
		
	}
	
}
